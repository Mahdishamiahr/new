"""End-to-end test of BotFather, the Bot API and stories (talks to a real server over TCP/HTTP).
Runs on a throw-away COPY of the project (a temp folder), so your real data/ is never touched."""
import os, shutil, subprocess, sys, tempfile
if not os.environ.get("WD_TEST_COPY"):
    here = os.path.dirname(os.path.abspath(__file__))
    tmp = tempfile.mkdtemp(prefix="wdtest_")
    dst = os.path.join(tmp, "app")
    shutil.copytree(here, dst, ignore=shutil.ignore_patterns("data", "android", ".git", "__pycache__", "*.zip"))
    code = subprocess.run([sys.executable, os.path.join(dst, os.path.basename(__file__))], env={**os.environ, "WD_TEST_COPY": "1"}).returncode
    shutil.rmtree(tmp, ignore_errors=True)
    sys.exit(code)
import json, time, socket, base64, urllib.request, threading, sys, io
import common, server
from common import encode_frame, recv_frame

srv = server.WindroidaServer("127.0.0.1", 0, tls=False, web_port=0)
srv.start()
PORT, WEB = srv.port, srv.web_port

class C:
    def __init__(s):
        s.sk = socket.create_connection(("127.0.0.1", PORT)); s.n = 0; s.events = []
        s.lock = threading.Lock(); s.res = {}
        threading.Thread(target=s.rd, daemon=True).start()
    def rd(s):
        try:
            while True:
                m = recv_frame(s.sk)
                if "event" in m: s.events.append(m)
                else: s.res[m["id"]] = m
        except Exception: pass
    def call(s, op, **kw):
        s.n += 1; i = s.n
        s.sk.sendall(encode_frame({"id": i, "op": op, **kw}))
        for _ in range(200):
            if i in s.res: return s.res.pop(i)
            time.sleep(0.02)
        raise TimeoutError(op)
    def ev(s, name, timeout=3):
        for _ in range(int(timeout/0.05)):
            for e in s.events:
                if e["event"] == name:
                    s.events.remove(e); return e
            time.sleep(0.05)
        return None

def reg(name):
    c = C()
    r = c.call("register", username=name, password="Passw0rd!x", display_name=name, sec_question="سوال تست خوب", sec_answer="جواب", device="t")
    assert r["ok"], r
    c.me = r["me"]; c.call("hello", caps=[])
    return c

def api(token, method, body=None, raw=None, qs=""):
    url = f"http://127.0.0.1:{WEB}/bot{token}/{method}{qs}"
    if raw is not None:
        req = urllib.request.Request(url, data=raw, headers={"Content-Type": "application/octet-stream"})
    elif body is not None:
        req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    else:
        req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req, timeout=40) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

ok = lambda c, m: print(("PASS " if c else "FAIL ") + m) or (c or sys.exit(1))

alice, bob = reg("alice"), reg("bobby")
# normal users can't take bot-ish names
r = C().call("register", username="evilbot", password="Passw0rd!x", display_name="x", sec_question="سوال تست خوب", sec_answer="جواب", device="t")
ok(not r["ok"], "register *bot username refused")
r = C().call("register", username="botfather", password="Passw0rd!x", display_name="x", sec_question="سوال تست خوب", sec_answer="جواب", device="t")
ok(not r["ok"], "register botfather refused")

# --- BotFather
r = alice.call("open_private", username="BotFather"); ok(r["ok"] and r["chat"]["peer"]["bot"], "BotFather chat opens; peer is bot")
cid = r["chat"]["id"]
ok(len(r["chat"]["peer"]["bot"]["commands"]) >= 5, "BotFather has commands")
def say(text):
    alice.events.clear(); alice.call("send", chat_id=cid, text=text)
    e = alice.ev("message", 5); return e["message"] if e else None
m = say("/newbot"); ok(m and "اسمش چی" in m["body"], "/newbot asks name")
m = say("My Shop"); ok(m and "نام کاربری" in m["body"], "asks username")
m = say("badname"); ok(m and "معتبر نیست" in m["body"], "rejects non-bot username")
m = say("shop_bot"); ok(m and m["secret"] and "`" in m["body"], "token message is secret")
token = m["body"].split("`")[1]; ok(":" in token, "token format " + token[:8])
bot_id = int(token.split(":")[0])
m = say("/mybots"); ok(m and m["markup"] and "shop_bot" in json.dumps(m["markup"]), "/mybots lists bot with buttons")
# callback: open bot menu
alice.events.clear(); r = alice.call("bot_callback", message_id=m["id"], data=f"bot:{bot_id}"); ok(r["ok"], "callback ok")
e = alice.ev("message_updated"); ok(e and "My Shop" in e["message"]["body"], "menu message edited in place")
# commands + description via flow
m = say("/setcommands"); alice.call("bot_callback", message_id=m["id"], data=f"cm:{bot_id}")
m = say("start - شروع\nhelp - کمک"); ok(m and "2 دستور" in m["body"] or (m and "۲" in m["body"]) or (m and "دستور ذخیره شد" in m["body"]), "commands saved: " + m["body"][:30])

# --- Bot API
code, r = api(token, "getMe"); ok(code == 200 and r["result"]["username"] == "shop_bot", "getMe")
code, r = api(token + "x", "getMe"); ok(code == 401, "bad token 401")
code, r = api("1:" + "a" * 30, "getMe"); ok(code == 401, "wrong secret 401")
code, r = api(token, "getMyCommands"); ok([c["command"] for c in r["result"]] == ["start", "help"], "getMyCommands")

# bob finds the bot, chats
r = bob.call("search_users", q="shop_bot"); ok(r["users"] and r["users"][0]["bot"]["commands"], "search finds bot with commands")
r = bob.call("open_private", username="shop_bot"); bchat = r["chat"]["id"]
bob.call("send", chat_id=bchat, text="/start")
code, r = api(token, "getUpdates", qs="?timeout=3"); ok(code == 200 and len(r["result"]) == 1, "getUpdates gets message")
u = r["result"][0]; ok(u["message"]["text"] == "/start" and u["message"]["from"]["username"] == "bobby", "update content")
# long poll wakes up
res = {}
threading.Thread(target=lambda: res.update(r=api(token, "getUpdates", qs=f"?timeout=10&offset={u['update_id']+1}")), daemon=True).start()
time.sleep(0.5); bob.call("send", chat_id=bchat, text="hello"); time.sleep(0.8)
ok("r" in res and res["r"][1]["result"][0]["message"]["text"] == "hello", "long poll wakes on new message")
# send with keyboard
kb = {"inline_keyboard": [[{"text": "Yes", "callback_data": "yes"}, {"text": "Site", "url": "https://example.com"}]]}
bob.events.clear()
code, r = api(token, "sendMessage", {"chat_id": bchat, "text": "Pick", "reply_markup": kb}); ok(code == 200, "sendMessage w/ keyboard")
e = bob.ev("message"); ok(e and e["message"]["markup"][0][0]["callback_data"] == "yes", "bob receives keyboard")
mid = e["message"]["id"]
code, r = api(token, "sendMessage", {"chat_id": bchat, "text": "x", "reply_markup": {"inline_keyboard": [[{"text": "a", "url": "javascript:alert(1)"}]]}}); ok(code == 400, "javascript: url refused")
# press button
bad = bob.call("bot_callback", message_id=mid, data="forged"); ok(not bad["ok"], "forged callback refused")
bob.call("bot_callback", message_id=mid, data="yes")
code, r = api(token, "getUpdates", qs=f"?offset=0&timeout=3")
cq = [x for x in r["result"] if "callback_query" in x][-1]["callback_query"]; ok(cq["data"] == "yes" and cq["from"]["username"] == "bobby", "callback_query delivered")
bob.events.clear(); api(token, "answerCallbackQuery", {"callback_query_id": cq["id"], "text": "Done!"})
e = bob.ev("bot_answer"); ok(e and e["text"] == "Done!", "answerCallbackQuery toast reaches bob")
code, r = api(token, "answerCallbackQuery", {"callback_query_id": cq["id"], "text": "again"}); ok(code == 400, "second answer refused")
# edit / delete
bob.events.clear(); code, r = api(token, "editMessageText", {"chat_id": bchat, "message_id": mid, "text": "Picked", "reply_markup": {"inline_keyboard": []}})
e = bob.ev("message_updated"); ok(code == 200 and e["message"]["body"] == "Picked" and not e["message"]["markup"], "editMessageText removes keyboard")
code, r = api(token, "deleteMessage", {"chat_id": bchat, "message_id": mid}); ok(code == 200, "deleteMessage")
# files
code, r = api(token, "sendDocument", raw=b"hello file", qs=f"?chat_id={bchat}&file_name=a.txt&caption=cap")
ok(code == 200 and r["result"]["file"]["name"] == "a.txt", "sendDocument raw")
code, r = api(token, "sendDocument", {"chat_id": bchat, "file_name": "b.txt", "file_base64": base64.b64encode(b"zz").decode()}); ok(code == 200, "sendDocument base64")
# bot can't write to chats it's not in
code, r = api(token, "sendMessage", {"chat_id": cid, "text": "hi"}); ok(code == 403, "foreign chat 403")
# file from user -> bot download
bob.call("send", chat_id=bchat, text="doc", file={"name": "u.txt", "data": base64.b64encode(b"userdata").decode()})
code, r = api(token, "getUpdates", qs="?offset=0&timeout=2"); fu = [x for x in r["result"] if x.get("message", {}).get("file")][-1]
req = urllib.request.Request(f"http://127.0.0.1:{WEB}/file/bot{token}/{fu['message']['message_id']}")
ok(urllib.request.urlopen(req).read() == b"userdata", "bot downloads user file")
# group privacy
r = alice.call("create_group", title="G", members=["bobby"]); gid = r["chat"]["id"]
alice.call("add_member", chat_id=gid, username="shop_bot")
code, r0 = api(token, "getUpdates", qs="?offset=0&timeout=1"); last = max([x["update_id"] for x in r0["result"]] or [0]); api(token, "getUpdates", qs=f"?offset={last+1}")
alice.call("send", chat_id=gid, text="just chatting"); alice.call("send", chat_id=gid, text="/help@shop_bot hi"); alice.call("send", chat_id=gid, text="/other@somebot")
time.sleep(0.3); code, r = api(token, "getUpdates", qs=f"?offset={last+1}&timeout=1")
ok([x["message"]["text"] for x in r["result"]] == ["/help@shop_bot hi"], "group privacy: only commands for this bot")
# bot cannot log in
r = C().call("login", username="shop_bot", password="x"); ok(not r["ok"], "bot login impossible")
# revoke token
alice.call("bot_callback", message_id=say("/token") and alice.call("history", chat_id=cid, limit=1)["messages"][-1]["id"], data=f"tok:{bot_id}")
hist = alice.call("history", chat_id=cid, limit=1)["messages"][-1]
alice.call("bot_callback", message_id=hist["id"], data=f"tokok:{bot_id}"); time.sleep(0.5)
code, r = api(token, "getMe"); ok(code == 401, "old token revoked")
newmsg = alice.call("history", chat_id=cid, limit=3)["messages"]; t2 = [x for x in newmsg if "`" in x["body"]][-1]["body"].split("`")[1]
code, r = api(t2, "getMe"); ok(code == 200, "new token works")
# not owner
r = bob.call("open_private", username="BotFather"); bcid = r["chat"]["id"]
bob.call("send", chat_id=bcid, text="/mybots"); time.sleep(1.2)
h = bob.call("history", chat_id=bcid, limit=3)["messages"]; ok("هنوز رباتی نساختی" in h[-1]["body"], "bob sees none of alice's bots")

# --- stories
bob.call("send", chat_id=bchat, text="x")
alice.call("send", chat_id=alice.call("open_private", username="bobby")["chat"]["id"], text="hey bob")
bob.events.clear()
r = alice.call("story_text", text="سلام دنیا", bg=3); ok(r["ok"], "story_text")
sid = r["story"]["id"]
ok(bob.ev("story_new") is not None, "bob gets story_new")
f = bob.call("stories_feed"); ok(len(f["groups"]) == 1 and f["groups"][0]["stories"][0]["text"] == "سلام دنیا", "bob sees alice's story")
carol = reg("carol"); f = carol.call("stories_feed"); ok(f["groups"] == [], "stranger sees nothing")
ok(not carol.call("story_seen", story_id=sid)["ok"], "stranger can't mark seen")
ok(bob.call("story_seen", story_id=sid)["ok"], "bob marks seen")
v = alice.call("story_viewers", story_id=sid); ok(len(v["viewers"]) == 1 and v["viewers"][0]["user"]["username"] == "bobby", "owner sees viewers")
ok(not bob.call("story_viewers", story_id=sid)["ok"], "viewer can't list viewers")
alice.events.clear(); bob.call("story_react", story_id=sid, emoji="❤️"); e = alice.ev("story_react"); ok(e and e["emoji"] == "❤️", "reaction event")
r = bob.call("story_reply", story_id=sid, text="عالی بود"); ok(r["ok"] and r["message"]["story"]["id"] == sid, "story reply is a DM with story chip")
# privacy: receipts off -> hidden
r = alice.call("story_text", text="second", bg=1); s2 = r["story"]["id"]
bob.call("privacy_set", read_receipts=False); bob.call("story_seen", story_id=s2)
ok(alice.call("story_viewers", story_id=s2)["viewers"] == [], "receipts-off viewer is hidden")
# media upload
from PIL import Image
buf = io.BytesIO(); Image.new("RGB", (300, 500), (200, 30, 30)).save(buf, "PNG")
key = alice.call("media_key")["media_key"]
def post(kind, data, extra=""):
    req = urllib.request.Request(f"http://127.0.0.1:{WEB}/storyupload?k={key}&kind={kind}{extra}", data=data, headers={"Content-Type": "application/octet-stream"})
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
code, r = post("image", buf.getvalue(), "&text=cap"); ok(code == 200 and r["story"]["w"] == 300, "image story uploaded")
isid = r["story"]["id"]
code, r = post("video", b"not a video at all....."); ok(code == 400, "fake video refused")
mp4 = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 40
code, r = post("video", mp4, "&dur=12"); ok(code == 200 and r["story"]["kind"] == "video", "video story uploaded")
code, r = post("video", mp4, "&dur=90"); ok(code == 400, "too long video refused")
bkey = bob.call("media_key")["media_key"]
d = urllib.request.urlopen(f"http://127.0.0.1:{WEB}/story/{isid}?k={bkey}").read(); ok(d[:2] == b"\xff\xd8", "bob downloads story image (jpeg)")
ckey = carol.call("media_key")["media_key"]
try: urllib.request.urlopen(f"http://127.0.0.1:{WEB}/story/{isid}?k={ckey}"); ok(False, "stranger blocked")
except urllib.error.HTTPError as e: ok(e.code == 404, "stranger gets 404 for story file")
# blocked -> hidden
bob.call("block", user_id=alice.me["id"]); ok(bob.call("stories_feed")["groups"] == [], "blocked: no stories")
bob.call("unblock", user_id=alice.me["id"])
# delete + expiry
r = alice.call("story_delete", story_id=sid); ok(r["ok"], "owner deletes")
db = common.connect_db(srv.db_path); db.execute("UPDATE stories SET expires_at=1"); db.commit(); db.close()
srv.sweep_stories(); import os
ok(not any(os.scandir(common.STORIES_DIR / str(alice.me["id"]))), "expired files removed from disk")
ok(bob.call("stories_feed")["groups"] == [], "expired stories gone from feed")
print("\nALL PASSED")
srv.stop()
