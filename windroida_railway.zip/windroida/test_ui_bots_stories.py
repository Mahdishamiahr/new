"""Browser test (Playwright + Chromium) of the stories and bot UI.
Runs on a throw-away COPY of the project (a temp folder), so your real data/ is never touched."""
import os, shutil, subprocess, sys, tempfile
if not os.environ.get("WD_TEST_COPY"):
    here = os.path.dirname(os.path.abspath(__file__))
    tmp = tempfile.mkdtemp(prefix="wdtest_")
    dst = os.path.join(tmp, "app")
    shutil.copytree(here, dst, ignore=shutil.ignore_patterns("data", "android", ".git", "__pycache__", "*.zip"))
    code = subprocess.run([sys.executable, os.path.join(dst, os.path.basename(__file__))], env={**os.environ, "WD_TEST_COPY": "1"}).returncode
    shutil.rmtree(tmp, ignore_errors=True)
    sys.exit(code)
import json, time, socket, threading, sys, re
import common, server
from common import encode_frame, recv_frame
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("SKIP: pip install playwright && playwright install chromium"); sys.exit(0)

srv = server.WindroidaServer("127.0.0.1", 0, tls=False, web_port=0); srv.start()
PORT, WEB = srv.port, srv.web_port
URL = f"http://127.0.0.1:{WEB}/"
def tcp_reg(name):
    sk = socket.create_connection(("127.0.0.1", PORT))
    sk.sendall(encode_frame({"id": 1, "op": "register", "username": name, "password": "Passw0rd!x", "display_name": name.capitalize(), "sec_question": "سوال تست خوب", "sec_answer": "جواب", "device": "t"}))
    r = recv_frame(sk); assert r["ok"], r
    return sk, r["me"]
def tcp_call(sk, i, op, **kw):
    sk.sendall(encode_frame({"id": i, "op": op, **kw}))
    while True:
        m = recv_frame(sk)
        if m.get("id") == i: return m
ska, a = tcp_reg("alice"); skb, b = tcp_reg("bobby")
r = tcp_call(ska, 2, "open_private", username="bobby"); tcp_call(ska, 3, "send", chat_id=r["chat"]["id"], text="hi bob")   # make them contacts

errs = []
def login(ctx, user):
    pg = ctx.new_page(); pg.on("pageerror", lambda e: errs.append((user, str(e)))); pg.on("console", lambda m: errs.append((user, m.text)) if m.type == "error" else None)
    pg.goto(URL); pg.wait_for_selector("#f-user", timeout=15000)
    pg.fill("#f-user", user); pg.fill("#f-pw", "Passw0rd!x"); pg.click("#abtn")
    pg.wait_for_selector("#app:not([hidden])", timeout=15000); pg.wait_for_selector("#stories:not([hidden])", timeout=8000)
    return pg
ok = lambda c, m: print(("PASS " if c else "FAIL ") + m) or (c or (print(errs), sys.exit(1)))

with sync_playwright() as p:
    br = p.chromium.launch()
    ca = br.new_context(viewport={"width": 1100, "height": 800}); cb = br.new_context(viewport={"width": 430, "height": 860})
    pa, pb = login(ca, "alice"), login(cb, "bobby")
    ok(pa.locator(".st-item").count() == 1 and "استوری من" in pa.inner_text("#stories"), "alice sees strip with 'my story'")
    # alice posts a text story through the UI
    pa.click(".st-plus"); pa.wait_for_selector(".dlg .st-tabs")
    pa.click(".st-tabs button:nth-child(2)"); pa.fill(".st-textbox textarea", "سلام از استوری!")
    pa.click(".st-chips button:nth-child(3)"); pa.click(".dlg .btn")
    pa.wait_for_selector(".st-ring:not(.none)", timeout=8000); ok(True, "alice published a text story (ring appears)")
    # bob sees alice's story live
    pb.wait_for_selector("#stories .st-item >> nth=1", timeout=8000); ok("Alice" in pb.inner_text("#stories"), "bob's strip shows Alice live (story_new event)")
    pb.click("#stories .st-item >> nth=1"); pb.wait_for_selector("#storyview .sv-text", timeout=5000)
    ok("سلام از استوری!" in pb.inner_text("#storyview"), "bob opens viewer, sees text")
    pb.screenshot(path="/tmp/shot_viewer.png")
    pb.fill(".sv-in", "عالی بود!"); pb.press(".sv-in", "Enter"); time.sleep(0.8)
    pb.click(".sv-heart"); time.sleep(0.5)
    pa.screenshot(path="/tmp/shot_alice_strip.png")
    pb.keyboard.press("Escape"); pb.wait_for_selector("#storyview", state="hidden", timeout=3000); ok(True, "viewer closes (Esc)")
    pb.wait_for_selector("#stories .st-ring.seen", timeout=3000); ok(True, "ring turns grey after viewing")
    # alice: viewers list + toast
    pa.wait_for_selector("#toast:not([hidden])", timeout=5000)
    pa.click("#stories .st-item >> nth=0"); pa.wait_for_selector("#storyview .sv-pill"); ok("۱" in pa.inner_text(".sv-pill"), "owner sees view count 1")
    pa.click(".sv-pill"); pa.wait_for_selector(".dlg .srow"); ok("Bobby" in pa.inner_text(".dlg"), "owner viewers list shows Bobby")
    pa.screenshot(path="/tmp/shot_viewers.png"); pa.click(".dlg h3 .iconbtn"); pa.keyboard.press("Escape")
    # reply arrived as DM with story chip
    pa.wait_for_selector(".chat >> nth=0"); pa.click(".chat >> nth=0"); pa.wait_for_selector(".story-chip", timeout=5000); ok(True, "reply shows 'reply to story' chip in alice's chat")

    # ---- BotFather in bob's UI
    pb.evaluate("openPrivate('BotFather')"); pb.wait_for_selector("#botstart:not([hidden])", timeout=8000); ok("شروع" in pb.inner_text("#botstart"), "empty bot chat shows START bar")
    ok(pb.locator(".botbadge").count() >= 0 and "ربات" in pb.inner_text("#hsub"), "header subtitle says ربات")
    ok("null" not in pb.inner_text("#botstart"), "START bar has no stray 'null'")
    pb.click("#botstart .btn"); pb.wait_for_selector(".bkbtn", timeout=8000); pb.wait_for_selector("#botstart", state="hidden", timeout=3000); ok(True, "START bar hides after first message")
    ok(not pb.locator("#callbtn").is_visible(), "no call buttons in a bot chat"); ok(pb.locator(".bkbtn").count() == 3, "BotFather menu has 3 inline buttons")
    pb.screenshot(path="/tmp/shot_botfather.png")
    pb.click(".bkbtn >> text=ساخت ربات جدید"); pb.get_by_text("اسمش چی باشه").first.wait_for(timeout=8000); ok(True, "pressing inline button starts /newbot")
    pb.fill("#input", "/"); pb.wait_for_selector("#botcmds:not([hidden]) .bcmd", timeout=3000); ok(pb.locator(".bcmd").count() >= 5, "typing / opens the command menu")
    pb.fill("#input", "")
    pb.fill("#input", "Pixel Shop"); pb.press("#input", "Enter"); pb.get_by_text("نام کاربری برای ربات").first.wait_for(timeout=8000)
    pb.fill("#input", "pixel_shop_bot"); pb.press("#input", "Enter"); pb.get_by_text("ربات ساخته شد").first.wait_for(timeout=8000); ok(True, "bot created through the UI")
    pb.screenshot(path="/tmp/shot_token.png")
    # a real notification path: token message is flagged secret
    token = re.search(r"\d+:[A-Za-z0-9_-]{30,}", pb.inner_text("#msgs")).group(0)
    import urllib.request
    me = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{WEB}/bot{token}/getMe").read()); ok(me["result"]["username"] == "pixel_shop_bot", "token from the UI works on the API")
    # bot sends a keyboard to bob, bob presses in UI
    pb.evaluate("openPrivate('pixel_shop_bot')"); pb.wait_for_selector("#botstart:not([hidden])", timeout=5000)
    cid = pb.evaluate("S.current")
    req = urllib.request.Request(f"http://127.0.0.1:{WEB}/bot{token}/sendMessage", data=json.dumps({"chat_id": cid, "text": "انتخاب کن", "reply_markup": {"inline_keyboard": [[{"text": "آره", "callback_data": "yes"}, {"text": "سایت", "url": "https://example.com"}]]}}).encode(), headers={"Content-Type": "application/json"})
    print(urllib.request.urlopen(req).read()[:80])
    pb.wait_for_selector(".bkbtn >> text=آره", timeout=5000); ok(pb.locator("a.bkbtn[target=_blank]").count() == 1, "bot keyboard rendered (callback + link buttons)")
    pb.click(".bkbtn >> text=آره")
    got = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{WEB}/bot{token}/getUpdates?timeout=3").read())["result"]
    ok(any("callback_query" in u and u["callback_query"]["data"] == "yes" for u in got), "button press reaches the bot as callback_query")
    pb.screenshot(path="/tmp/shot_bot_kb.png")
    br.close()
bad = [e for e in errs if "favicon" not in e[1] and "Failed to load resource" not in e[1]]
print("JS errors:", bad)
ok(not bad, "no JS errors in console")
print("UI ALL PASSED"); srv.stop()
