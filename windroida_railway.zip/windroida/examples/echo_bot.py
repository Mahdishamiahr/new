#!/usr/bin/env python3
"""A tiny Windroida bot (Python standard library only - no pip install).

  1. In the app open BotFather (side menu), send /newbot and copy the token.
  2. python examples/echo_bot.py https://YOUR-SERVER:8443 123:ABCDEF...        (add --insecure for a self-signed certificate)

It answers /start with buttons, counts button presses, echoes your text and tells you about files you send.
"""
import json
import ssl
import sys
import time
import urllib.error
import urllib.request


class Bot:
    def __init__(self, base, token, insecure=False):
        self.url = f"{base.rstrip('/')}/bot{token}/"
        self.ctx = ssl._create_unverified_context() if insecure else None

    def call(self, method, **params):
        req = urllib.request.Request(self.url + method, data=json.dumps(params).encode(),
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=60, context=self.ctx) as r:
                return json.loads(r.read())["result"]
        except urllib.error.HTTPError as e:                     # the server explains what went wrong
            raise RuntimeError(json.loads(e.read()).get("description", str(e)))


def keyboard(n):
    return {"inline_keyboard": [[{"text": f"👆 {n} بار زدی", "callback_data": f"count:{n + 1}"}],
                                [{"text": "🌐 مستندات", "url": "https://example.com"}]]}


def handle(bot, upd):
    if "message" in upd:
        m = upd["message"]
        chat, text = m["chat"]["id"], m.get("text", "")
        if text.startswith("/start"):
            bot.call("sendMessage", chat_id=chat, text=f"سلام {m['from']['first_name']}! 👋\nیه چیزی بنویس تا تکرارش کنم.",
                     reply_markup=keyboard(0))
        elif m.get("file"):
            f = m["file"]
            bot.call("sendMessage", chat_id=chat, text=f"فایل «{f['name']}» ({f['size']} بایت) رسید ✅",
                     reply_to_message_id=m["message_id"])
        elif text:
            bot.call("sendChatAction", chat_id=chat, action="typing")
            bot.call("sendMessage", chat_id=chat, text="🔁 " + text, reply_to_message_id=m["message_id"])
    elif "callback_query" in upd:
        q = upd["callback_query"]
        n = int(q["data"].split(":")[1])
        bot.call("editMessageText", chat_id=q["message"]["chat"]["id"], message_id=q["message"]["message_id"],
                 text=f"دکمه رو {n} بار زدی", reply_markup=keyboard(n))
        bot.call("answerCallbackQuery", callback_query_id=q["id"], text="ثبت شد!")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 2:
        sys.exit(__doc__)
    bot = Bot(args[0], args[1], insecure="--insecure" in sys.argv)
    me = bot.call("getMe")
    bot.call("setMyCommands", commands=[{"command": "start", "description": "شروع"}])
    print(f"bot @{me['username']} is running (Ctrl+C to stop)")
    offset = 0
    while True:
        try:
            for upd in bot.call("getUpdates", offset=offset, timeout=25):
                offset = upd["update_id"] + 1
                try:
                    handle(bot, upd)
                except Exception as e:                           # one bad update must not stop the bot
                    print("handler error:", e)
        except KeyboardInterrupt:
            break
        except Exception as e:
            print("poll error:", e)
            time.sleep(3)


if __name__ == "__main__":
    main()
